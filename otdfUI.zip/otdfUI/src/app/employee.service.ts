import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { Employee } from './employee';
@Injectable()
export class EmployeeService {

  constructor(private http:Http) { }

  registerEmployee(employee:Employee){
    console.log(employee);
    let url='http://localhost:8080/registrationweb/employee';
    let headers = new Headers(
      {
        'Content-Type':'application/json'
      });
    return this.http.post(url, employee ,{headers: headers, withCredentials:true});
  }
}
