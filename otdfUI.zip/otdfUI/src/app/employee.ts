export class Employee{
    name:string;
    contact:string;
    batch:string;
    userid:string;
    password:string;
}