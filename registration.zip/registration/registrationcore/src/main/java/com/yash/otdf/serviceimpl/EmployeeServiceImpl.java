package com.yash.otdf.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.otdf.dao.EmployeeDAO;
import com.yash.otdf.domain.Employee;
import com.yash.otdf.service.EmployeeService;

/**
 * This class is implementation of EmployeeService interface.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDAO employeeDAO;

	@Override
	public int register(Employee employee) {
		return employeeDAO.insert(employee);
	}
	
}
