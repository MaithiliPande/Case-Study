package com.yash.otdf.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.otdf.dao.EmployeeDAO;
import com.yash.otdf.domain.Employee;

/**
 * This is the implementation class of EmployeeDAO interface.
 * It has the method implementations. 
 * @author maithili.pande
 *
 */
@Repository
public class EmployeeDAOImpl implements EmployeeDAO{
	@Autowired
	SessionFactory sessionFactory;

	/**
	 * This method performs the operation to insert the employee into database.
	 */
	public int insert(Employee employee) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		return 1;
	}
}
