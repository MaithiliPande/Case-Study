package com.yash.otdf.dao;

import com.yash.otdf.domain.Employee;

/**
 * this interface will perform the operations related users.
 * It contains abstract methods of the operations.
 * @author maithili.pande
 *
 */
public interface EmployeeDAO {
	public int insert(Employee employee);
}
