package com.yash.otdf.service;

import com.yash.otdf.domain.Employee;

/**
 * This will perform service related tasks on employee
 */
public interface EmployeeService {
	public int register(Employee employee);
}
