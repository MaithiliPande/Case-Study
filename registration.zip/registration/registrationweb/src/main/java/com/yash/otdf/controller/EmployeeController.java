package com.yash.otdf.controller;
/**
 * This is rest controller which contains a method to register employee.
 * It control the request and perform the registration operation accordingly.
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.otdf.domain.Employee;
import com.yash.otdf.service.EmployeeService;
@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	/**
	 * This method will control the request and perform the registration operation accordingly.
	 * @param employee
	 * @return
	 */
	@RequestMapping(value="/employee",method=RequestMethod.POST)
	public int registerEmployee(@RequestBody Employee employee) {
		return employeeService.register(employee);
	}
}
